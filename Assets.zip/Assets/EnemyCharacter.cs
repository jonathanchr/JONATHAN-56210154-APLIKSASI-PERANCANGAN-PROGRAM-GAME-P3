using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyCharacter : MonoBehaviour
{
    public int health = 10; // Tingkat health musuh

    // Mengurangi health musuh
    public void Hurt(int damage)
    {
        health -= damage;
        Debug.Log($"Enemy Health: {health}");

        if (health <= 0)
        {
            Debug.Log("Enemy is dead");
            // Tambahkan logika kematian musuh di sini (misalnya, animasi atau penghancuran objek)
            Destroy(this.gameObject);
        }
    }
}
