using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fireball : MonoBehaviour
{
    public float speed = 10.0f;
    public int damage = 1;

    void Update()
    {
        // Menggerakkan bola api maju sesuai arah yang dihadapinya
        transform.Translate(0, 0, speed * Time.deltaTime);
    }

    void OnTriggerEnter(Collider other)
    {
        // Mendapatkan komponen PlayerCharacter dari objek yang ditabrak
        PlayerCharacter player = other.GetComponent<PlayerCharacter>();
        if (player != null)
        {
            Debug.Log("Player hit"); // Menampilkan log jika bola api mengenai pemain
        }

        // Menghancurkan bola api setelah terjadi tabrakan
        Destroy(this.gameObject);
    }
}
