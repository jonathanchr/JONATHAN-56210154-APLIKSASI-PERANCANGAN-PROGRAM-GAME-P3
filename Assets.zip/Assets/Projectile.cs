using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour
{
    public float speed = 10.0f;
    public int damage = 1; // Tingkat damage proyektil

    void Update()
    {
        // Menggerakkan proyektil maju sesuai arah yang dihadapinya
        transform.Translate(0, 0, speed * Time.deltaTime);
    }

    void OnTriggerEnter(Collider other)
    {
        // Jika proyektil menabrak player
        PlayerCharacter player = other.GetComponent<PlayerCharacter>();
        if (player != null)
        {
            player.Hurt(damage); // Berikan damage sesuai dengan proyektil
        }

        // Jika proyektil menabrak musuh
        EnemyCharacter enemy = other.GetComponent<EnemyCharacter>();
        if (enemy != null)
        {
            enemy.Hurt(damage); // Berikan damage ke musuh
        }

        // Menghancurkan proyektil setelah terjadi tabrakan
        Destroy(this.gameObject);
    }
}
