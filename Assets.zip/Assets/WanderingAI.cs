using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WanderingAI : MonoBehaviour
{
    public float speed = 3.0f;
    public float obstacleRange = 5.0f;
    private bool isAlive;

    [SerializeField] GameObject fireballPrefab; // Prefab untuk bola api
    private GameObject fireball; // Menyimpan instance dari bola api

    void Start()
    {
        isAlive = true; // Inisialisasi AI dalam keadaan hidup
    }

    void Update()
    {
        if (isAlive)
        {
            transform.Translate(0, 0, speed * Time.deltaTime);

            Ray ray = new Ray(transform.position, transform.forward);
            RaycastHit hit;

            if (Physics.SphereCast(ray, 0.75f, out hit))
            {
                GameObject hitObject = hit.transform.gameObject;
                // Deteksi apakah objek yang terkena ray adalah PlayerCharacter
                if (hitObject.GetComponent<PlayerCharacter>())
                {
                    // Jika fireball belum ada, instantiate fireballPrefab
                    if (fireball == null)
                    {
                        fireball = Instantiate(fireballPrefab) as GameObject;
                        // Menempatkan fireball di depan AI dan mengarahkannya ke arah yang sama
                        fireball.transform.position = transform.TransformPoint(Vector3.forward * 1.5f);
                        fireball.transform.rotation = transform.rotation;
                    }
                }
                else if (hit.distance < obstacleRange)
                {
                    float angle = Random.Range(-110, 110);
                    transform.Rotate(0, angle, 0);
                }
            }
        }
    }

    // Metode untuk mengatur status hidup/mati AI dari luar kelas ini
    public void SetAlive(bool alive)
    {
        isAlive = alive;
    }
}
